import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import 'package:uuid/uuid.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const clinicBn = 'মডেল ক্লিনিক এন্ড ডায়াগনস্টিক সেন্টার';
const clinicEn = 'Model Clinic & Diagnostic Center';
const uuid = Uuid();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final url = const String.fromEnvironment('SUPABASE_URL');
  final key = const String.fromEnvironment('SUPABASE_ANON_KEY');
  if (url.isNotEmpty && key.isNotEmpty) {
    await Supabase.initialize(url: url, anonKey: key);
  }
  await LocalStore.instance.init();
  runApp(const ClinicApp());
}

class LocalStore {
  LocalStore._();
  static final instance = LocalStore._();
  late Database db;

  Future<void> init() async {
    final path = p.join(await getDatabasesPath(), 'model_clinic.db');
    db = await openDatabase(path, version: 1, onCreate: (d, v) async {
      await d.execute('CREATE TABLE patients(id TEXT PRIMARY KEY, name TEXT NOT NULL, phone TEXT, age TEXT, created_at TEXT, synced INTEGER DEFAULT 0)');
      await d.execute('CREATE TABLE doctors(id TEXT PRIMARY KEY, name TEXT NOT NULL, specialty TEXT, fee REAL DEFAULT 0, created_at TEXT, synced INTEGER DEFAULT 0)');
      await d.execute('CREATE TABLE appointments(id TEXT PRIMARY KEY, patient_name TEXT, patient_phone TEXT, doctor_id TEXT, doctor_name TEXT, visit_date TEXT, serial_no INTEGER, fee REAL DEFAULT 0, status TEXT, created_at TEXT, synced INTEGER DEFAULT 0)');
    });
  }

  Future<List<Map<String, Object?>>> all(String table) => db.query(table, orderBy: 'created_at DESC');
  Future<int> count(String table) async => Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM $table')) ?? 0;
  Future<void> add(String table, Map<String, Object?> row) async => db.insert(table, row, conflictAlgorithm: ConflictAlgorithm.replace);
}

class ClinicApp extends StatelessWidget {
  const ClinicApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: clinicEn,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff1769aa), secondary: const Color(0xffe879a8)), useMaterial3: true),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  int patients = 0, doctors = 0, appointments = 0;
  List<Map<String, Object?>> rows = [];
  final tabs = const ['ড্যাশবোর্ড', 'রোগী', 'ডাক্তার', 'সিরিয়াল'];
  final tables = const ['patients', 'patients', 'doctors', 'appointments'];

  @override
  void initState() { super.initState(); refresh(); }

  Future<void> refresh() async {
    patients = await LocalStore.instance.count('patients');
    doctors = await LocalStore.instance.count('doctors');
    appointments = await LocalStore.instance.count('appointments');
    if (tab > 0) rows = await LocalStore.instance.all(tables[tab]);
    if (mounted) setState(() {});
  }

  Future<void> addRecord() async {
    final name = TextEditingController();
    final phone = TextEditingController();
    final extra = TextEditingController();
    final fee = TextEditingController();
    final isDoctor = tab == 2;
    final isAppointment = tab == 3;
    await showDialog(context: context, builder: (ctx) => AlertDialog(
      title: Text(isDoctor ? 'নতুন ডাক্তার' : isAppointment ? 'নতুন সিরিয়াল' : 'নতুন রোগী'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: InputDecoration(labelText: isDoctor ? 'ডাক্তারের নাম' : 'রোগীর নাম')),
        if (!isDoctor) TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'মোবাইল নম্বর')),
        TextField(controller: extra, decoration: InputDecoration(labelText: isDoctor ? 'বিশেষজ্ঞতা' : isAppointment ? 'ডাক্তারের নাম' : 'বয়স')),
        if (isDoctor || isAppointment) TextField(controller: fee, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'ফি (টাকা)')),
      ])),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('বাতিল')),
        FilledButton(onPressed: () async {
          if (name.text.trim().isEmpty) return;
          final now = DateTime.now().toIso8601String();
          if (isDoctor) {
            await LocalStore.instance.add('doctors', {'id': uuid.v4(), 'name': name.text.trim(), 'specialty': extra.text.trim(), 'fee': double.tryParse(fee.text) ?? 0, 'created_at': now, 'synced': 0});
          } else if (isAppointment) {
            final next = (await LocalStore.instance.count('appointments')) + 1;
            await LocalStore.instance.add('appointments', {'id': uuid.v4(), 'patient_name': name.text.trim(), 'patient_phone': phone.text.trim(), 'doctor_id': '', 'doctor_name': extra.text.trim(), 'visit_date': DateTime.now().toIso8601String().substring(0,10), 'serial_no': next, 'fee': double.tryParse(fee.text) ?? 0, 'status': 'waiting', 'created_at': now, 'synced': 0});
          } else {
            await LocalStore.instance.add('patients', {'id': uuid.v4(), 'name': name.text.trim(), 'phone': phone.text.trim(), 'age': extra.text.trim(), 'created_at': now, 'synced': 0});
          }
          if (ctx.mounted) Navigator.pop(ctx);
          await refresh();
        }, child: const Text('সংরক্ষণ')),
      ],
    ));
  }

  @override
  Widget build(BuildContext context) {
    final isList = tab != 0;
    return Scaffold(
      appBar: AppBar(title: const Text('Model Clinic | মডেল ক্লিনিক'), actions: [
        IconButton(onPressed: refresh, icon: const Icon(Icons.refresh), tooltip: 'রিফ্রেশ'),
      ]),
      body: RefreshIndicator(onRefresh: refresh, child: isList ? ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(tabs[tab], style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 12),
          if (rows.isEmpty) const Padding(padding: EdgeInsets.all(28), child: Center(child: Text('এখনো কোনো তথ্য যোগ করা হয়নি'))),
          ...rows.map((r) => Card(child: ListTile(
            leading: Icon(tab == 2 ? Icons.medical_services : tab == 3 ? Icons.confirmation_number : Icons.person),
            title: Text('${r['name'] ?? r['patient_name'] ?? ''}'),
            subtitle: Text(tab == 2 ? '${r['specialty'] ?? ''} • ফি: ${r['fee'] ?? 0} টাকা' : tab == 3 ? 'সিরিয়াল: ${r['serial_no']} • ডাক্তার: ${r['doctor_name']}' : 'ফোন: ${r['phone'] ?? ''} • বয়স: ${r['age'] ?? ''}'),
          ))),
        ],
      ) : ListView(padding: const EdgeInsets.all(16), children: [
        Card(color: const Color(0xffeaf3fb), child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
          Image.asset('assets/model_clinic_logo.jpg', height: 150, fit: BoxFit.contain),
          const SizedBox(height: 10),
          const Text(clinicBn, textAlign: TextAlign.center, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xff145b91))),
          const SizedBox(height: 5), const Text(clinicEn, textAlign: TextAlign.center),
          const SizedBox(height: 12), const Text('অফলাইন-ফার্স্ট ক্লিনিক ম্যানেজমেন্ট', style: TextStyle(color: Colors.green)),
        ]))),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: _stat('রোগী', patients, Icons.people)),
          const SizedBox(width: 8), Expanded(child: _stat('ডাক্তার', doctors, Icons.medical_services)),
          const SizedBox(width: 8), Expanded(child: _stat('সিরিয়াল', appointments, Icons.confirmation_number)),
        ]),
        const SizedBox(height: 16),
        const Card(child: ListTile(leading: Icon(Icons.wifi_off), title: Text('অফলাইনেও তথ্য সংরক্ষিত হবে'), subtitle: Text('এই সংস্করণে তথ্য এই ফোনে থাকে। একাধিক ফোনে সিঙ্ক চালুর জন্য Supabase সেটআপ বাকি।'))),
        const Card(child: ListTile(leading: Icon(Icons.security), title: Text('ব্যবহারকারীর ভূমিকা'), subtitle: Text('অ্যাডমিন / রিসেপশন / হিসাবরক্ষক — নিরাপদ লগইন ও অনুমতি পরের ধাপে যুক্ত হবে।'))),
      ])),
      floatingActionButton: isList ? FloatingActionButton.extended(onPressed: addRecord, icon: const Icon(Icons.add), label: const Text('নতুন যোগ করুন')) : null,
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (v) async { setState(() { tab = v; }); await refresh(); }, destinations: const [
        NavigationDestination(icon: Icon(Icons.dashboard), label: 'হোম'),
        NavigationDestination(icon: Icon(Icons.people), label: 'রোগী'),
        NavigationDestination(icon: Icon(Icons.medical_services), label: 'ডাক্তার'),
        NavigationDestination(icon: Icon(Icons.confirmation_number), label: 'সিরিয়াল'),
      ]),
    );
  }

  Widget _stat(String label, int value, IconData icon) => Card(child: Padding(padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 6), child: Column(children: [
    Icon(icon, color: const Color(0xff1769aa)), const SizedBox(height: 8),
    Text('$value', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
    Text(label),
  ])));
}
