# Model Clinic & Diagnostic Center

A Flutter starter project for the Android clinic-management app.

## Included in this starter
- Bangla + English clinic branding
- Dashboard starter
- Doctors, patients, appointments and accounts feature entry points
- GitHub Actions workflow to build an Android APK in the cloud

## Important
This is a starter, not a completed production clinic system. Database connection, authentication, appointment serials, doctor settlements, detailed reports and role permissions still need to be implemented and tested.

## Build APK from GitHub
1. Create a GitHub repository named `model-clinic-app`.
2. Upload the contents of this folder to the repository (including the hidden `.github` folder).
3. Open the repository's **Actions** tab.
4. Run **Build Android APK** using **Run workflow**.
5. Download the APK from the completed workflow's Artifacts section.

No passwords, OTPs, or Supabase service-role keys should be committed to this repository.
