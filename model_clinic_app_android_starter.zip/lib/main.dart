import 'package:flutter/material.dart';

void main() => runApp(const ModelClinicApp());

class ModelClinicApp extends StatelessWidget {
  const ModelClinicApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Model Clinic & Diagnostic Center',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1976D2)),
        useMaterial3: true,
      ),
      home: const ClinicDashboard(),
    );
  }
}

class ClinicDashboard extends StatelessWidget {
  const ClinicDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      ('ডাক্তার / Doctors', Icons.medical_services_outlined),
      ('রোগী / Patients', Icons.people_alt_outlined),
      ('অ্যাপয়েন্টমেন্ট / Appointments', Icons.calendar_month_outlined),
      ('হিসাব / Accounts', Icons.account_balance_wallet_outlined),
      ('রিপোর্ট / Reports', Icons.bar_chart_outlined),
      ('সেটিংস / Settings', Icons.settings_outlined),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('মডেল ক্লিনিক'),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            color: const Color(0xFFEAF3FF),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: const [
                  Icon(Icons.local_hospital, size: 52, color: Color(0xFF1976D2)),
                  SizedBox(height: 10),
                  Text('মডেল ক্লিনিক এন্ড ডায়াগনস্টিক সেন্টার',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                  SizedBox(height: 6),
                  Text('Model Clinic & Diagnostic Center',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 15)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          const Text('আজকের সারসংক্ষেপ / Today’s Overview',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          const Row(
            children: [
              Expanded(child: _StatCard(title: 'রোগী / Patients', value: '0')),
              SizedBox(width: 10),
              Expanded(child: _StatCard(title: 'সিরিয়াল / Serials', value: '0')),
            ],
          ),
          const SizedBox(height: 14),
          ...items.map((item) => Card(
                child: ListTile(
                  leading: Icon(item.$2, color: const Color(0xFF1976D2)),
                  title: Text(item.$1),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('${item.$1} — পরবর্তী ধাপে যুক্ত হবে')),
                  ),
                ),
              )),
          const SizedBox(height: 12),
          const Text(
            'নোট: এটি প্রাথমিক ডেমো। রোগী, ডাক্তার, সিরিয়াল, পেমেন্ট ও রিপোর্টের পূর্ণ কার্যকারিতা পরবর্তী ধাপে যুক্ত হবে।',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.black54),
          ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title;
  final String value;
  const _StatCard({required this.title, required this.value});

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Text(title, textAlign: TextAlign.center),
              const SizedBox(height: 8),
              Text(value, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      );
}
