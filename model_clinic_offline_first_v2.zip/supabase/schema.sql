-- Run this in Supabase SQL Editor after creating a project.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'reception' check (role in ('admin','reception','accountant','doctor')),
  created_at timestamptz default now()
);
create table if not exists public.patients (
  id uuid primary key,
  name text not null,
  phone text,
  age text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create table if not exists public.doctors (
  id uuid primary key,
  name text not null,
  specialty text,
  fee numeric default 0,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create table if not exists public.appointments (
  id uuid primary key,
  patient_name text,
  patient_phone text,
  doctor_id uuid,
  doctor_name text,
  visit_date date,
  serial_no integer,
  fee numeric default 0,
  status text default 'waiting',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
alter table public.profiles enable row level security;
alter table public.patients enable row level security;
alter table public.doctors enable row level security;
alter table public.appointments enable row level security;
-- Authenticated clinic users can access clinic records. Restrict roles further before production.
create policy "signed in can read profiles" on public.profiles for select to authenticated using (true);
create policy "signed in can read patients" on public.patients for select to authenticated using (true);
create policy "signed in can write patients" on public.patients for all to authenticated using (true) with check (true);
create policy "signed in can read doctors" on public.doctors for select to authenticated using (true);
create policy "signed in can write doctors" on public.doctors for all to authenticated using (true) with check (true);
create policy "signed in can read appointments" on public.appointments for select to authenticated using (true);
create policy "signed in can write appointments" on public.appointments for all to authenticated using (true) with check (true);
