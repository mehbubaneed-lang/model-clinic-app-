# Model Clinic & Diagnostic Center — Offline-first starter

This is a **working local-data starter**, not yet a finished multi-phone clinic system.

## Current features
- Android Flutter app
- Official clinic logo image on dashboard
- Bangla + English clinic name
- Local SQLite storage (works without internet)
- Add/list patients, doctors and appointments
- Basic serial number generation

## Important limitations
- Data is currently stored on each phone separately.
- Cloud sync, secure login, role permissions, payments, commissions, reports and backup are NOT finished.
- Do not use for real patient records until authentication, role-based security, tested sync and backups are completed.
- Never put a Supabase service-role key in this app or GitHub. Only the public anon key may be used in a client app with correctly configured RLS.

## Supabase preparation
1. Create a Supabase project.
2. Open SQL Editor and run `supabase/schema.sql`.
3. Copy Project URL and anon/public key.
4. Configure the Android build with `SUPABASE_URL` and `SUPABASE_ANON_KEY` dart defines.
5. Cloud sync still needs to be implemented and tested; adding credentials alone does not enable sync.

## Build
```bash
flutter pub get
flutter create --platforms=android --org com.modelclinic .
flutter build apk --release
```


## App icon
The supplied Model Clinic logo is also configured as the Android launcher icon. GitHub Actions generates the Android icon assets during the build.
