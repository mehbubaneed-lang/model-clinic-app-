# Model Clinic Android starter — launcher icon fixed

This package uses the clinic logo supplied by the user as the Android launcher icon.
It also displays the same logo at the top of the demo dashboard.

## Build
The GitHub Actions workflow runs `flutter pub get`, then `dart run flutter_launcher_icons`,
then builds the release APK.

## Important
This is a demo starter. Patient records, appointment creation, staff login, offline database,
cloud synchronization, payments and reports are not implemented in this package yet.
