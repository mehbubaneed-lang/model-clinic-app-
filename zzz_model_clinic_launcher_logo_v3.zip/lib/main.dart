import 'package:flutter/material.dart';

void main() => runApp(const ModelClinicApp());

class ModelClinicApp extends StatelessWidget {
  const ModelClinicApp({super.key});

  @override
  Widget build(BuildContext context) {
    const blue = Color(0xFF343A91);
    const cyan = Color(0xFF08A5BE);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Model Clinic',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: blue),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7FAFC),
      ),
      home: const DashboardPage(),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Text('Model Clinic'),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Card(
            color: Colors.white,
            elevation: 1,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Image.asset('assets/app_icon.png', height: 150, fit: BoxFit.contain),
                  const SizedBox(height: 10),
                  const Text(
                    'মডেল ক্লিনিক এন্ড ডায়াগনস্টিক সেন্টার',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Model Clinic & Diagnostic Center',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 15, color: Color(0xFF08A5BE)),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text('Dashboard', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          const _FeatureTile(icon: Icons.people_alt_outlined, title: 'Patients / রোগী', subtitle: 'Patient management'),
          const _FeatureTile(icon: Icons.medical_services_outlined, title: 'Doctors / ডাক্তার', subtitle: 'Doctor information'),
          const _FeatureTile(icon: Icons.event_available_outlined, title: 'Appointments / সিরিয়াল', subtitle: 'Appointments and serials'),
          const _FeatureTile(icon: Icons.account_balance_wallet_outlined, title: 'Accounts / হিসাব', subtitle: 'Fees and payments'),
          const _FeatureTile(icon: Icons.assessment_outlined, title: 'Reports / রিপোর্ট', subtitle: 'Daily and monthly reports'),
          const SizedBox(height: 12),
          const Text(
            'Demo dashboard: management, login and cloud sync features are not enabled in this starter build.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.black54, fontSize: 12),
          ),
        ],
      ),
    );
  }
}

class _FeatureTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const _FeatureTile({required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Icon(icon, color: const Color(0xFF08A5BE), size: 30),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
      ),
    );
  }
}
