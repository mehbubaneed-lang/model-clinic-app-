# Model Clinic V5 - Full offline starter

This ZIP contains a Flutter Android app source with local SQLite storage.

Included working modules:
- Patient records including diagnosis and prescription
- Doctor details, fee and commission
- Doctor schedule records
- Reception appointments / serial records
- Income and expense entries with payment method
- Dashboard totals and basic reports
- Search, add, edit and delete for each module

Important limitations:
- This version stores data on each phone only. It does NOT yet sync multiple phones.
- No login/role security or automatic cloud backup is configured.
- Schedule and appointment records currently use doctor/patient numeric IDs; add the doctor/patient first and use their record ID.
- Before replacing an installed app, export/backup patient data if you have entered real records. Android uninstall can erase local data.
- The supplied project does not contain the clinic's private logo image. Keep your existing launcher-icon workflow/assets in the GitHub repository when applying this source.
