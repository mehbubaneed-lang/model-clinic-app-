import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import 'package:intl/intl.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await ClinicDb.instance.init();
  runApp(const ClinicApp());
}

class ClinicDb {
  ClinicDb._();
  static final instance = ClinicDb._();
  late Database db;

  Future<void> init() async {
    final path = p.join(await getDatabasesPath(), 'model_clinic_v5.db');
    db = await openDatabase(path, version: 1, onCreate: (d, v) async {
      await d.execute('''CREATE TABLE patients(
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, age TEXT,
        gender TEXT, phone TEXT, address TEXT, problem TEXT, prescription TEXT,
        created_at TEXT)''');
      await d.execute('''CREATE TABLE doctors(
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, qualification TEXT,
        specialty TEXT, phone TEXT, fee REAL DEFAULT 0, commission REAL DEFAULT 0,
        notes TEXT)''');
      await d.execute('''CREATE TABLE schedules(
        id INTEGER PRIMARY KEY AUTOINCREMENT, doctor_id INTEGER, day TEXT,
        start_time TEXT, end_time TEXT, room TEXT, notes TEXT)''');
      await d.execute('''CREATE TABLE appointments(
        id INTEGER PRIMARY KEY AUTOINCREMENT, patient_id INTEGER, doctor_id INTEGER,
        visit_date TEXT, serial TEXT, status TEXT, fee REAL DEFAULT 0, notes TEXT)''');
      await d.execute('''CREATE TABLE transactions(
        id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, category TEXT, amount REAL,
        method TEXT, ref TEXT, entry_date TEXT, notes TEXT)''');
    });
  }

  Future<List<Map<String,dynamic>>> rows(String table) => db.query(table, orderBy: 'id DESC');
  Future<int> add(String table, Map<String,dynamic> data) => db.insert(table, data);
  Future<int> edit(String table, int id, Map<String,dynamic> data) =>
      db.update(table, data, where: 'id=?', whereArgs: [id]);
  Future<int> remove(String table, int id) => db.delete(table, where: 'id=?', whereArgs: [id]);
  Future<int> count(String table) async =>
      Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM $table')) ?? 0;
  Future<double> sum(String sql) async {
    final r = await db.rawQuery(sql);
    return ((r.first.values.first as num?) ?? 0).toDouble();
  }
}

class ClinicApp extends StatelessWidget {
  const ClinicApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Model Clinic',
    theme: ThemeData(colorSchemeSeed: const Color(0xff087f78), useMaterial3: true),
    home: const HomePage(),
  );
}

class Module {
  final String title, table;
  final IconData icon;
  final List<FieldDef> fields;
  const Module(this.title, this.table, this.icon, this.fields);
}
class FieldDef {
  final String key, label;
  final bool number, multiline, required;
  const FieldDef(this.key, this.label, {this.number=false, this.multiline=false, this.required=false});
}

final modules = <Module>[
  Module('রোগী / Patients','patients',Icons.people_alt, const [
    FieldDef('name','রোগীর নাম / Name',required:true), FieldDef('age','বয়স / Age',number:true),
    FieldDef('gender','লিঙ্গ / Gender'), FieldDef('phone','মোবাইল / Phone'),
    FieldDef('address','ঠিকানা / Address',multiline:true), FieldDef('problem','সমস্যা / Diagnosis',multiline:true),
    FieldDef('prescription','প্রেসক্রিপশন / Prescription',multiline:true),
  ]),
  Module('ডাক্তার / Doctors','doctors',Icons.medical_services, const [
    FieldDef('name','ডাক্তারের নাম / Name',required:true), FieldDef('qualification','যোগ্যতা / Qualification'),
    FieldDef('specialty','বিশেষজ্ঞ / Specialty'), FieldDef('phone','মোবাইল / Phone'),
    FieldDef('fee','ভিজিট ফি / Visit fee',number:true), FieldDef('commission','কমিশন / Commission',number:true),
    FieldDef('notes','অন্যান্য তথ্য / Details',multiline:true),
  ]),
  Module('ডাক্তারের সময়সূচি / Schedule','schedules',Icons.calendar_month, const [
    FieldDef('doctor_id','ডাক্তারের ID',number:true,required:true), FieldDef('day','দিন / Day',required:true),
    FieldDef('start_time','শুরুর সময় / Start time'), FieldDef('end_time','শেষের সময় / End time'),
    FieldDef('room','রুম / Room'), FieldDef('notes','নোট / Notes',multiline:true),
  ]),
  Module('অ্যাপয়েন্টমেন্ট ও সিরিয়াল / Reception','appointments',Icons.confirmation_number, const [
    FieldDef('patient_id','রোগীর ID',number:true,required:true), FieldDef('doctor_id','ডাক্তারের ID',number:true,required:true),
    FieldDef('visit_date','তারিখ / Date (YYYY-MM-DD)',required:true), FieldDef('serial','সিরিয়াল / Serial'),
    FieldDef('status','অবস্থা / Status (Waiting/Done/Cancelled)'),
    FieldDef('fee','ফি / Fee',number:true), FieldDef('notes','নোট / Notes',multiline:true),
  ]),
  Module('আয়-ব্যয় / Accounts','transactions',Icons.account_balance_wallet, const [
    FieldDef('type','ধরন / Type (Income/Expense)',required:true), FieldDef('category','খাত / Category'),
    FieldDef('amount','টাকার পরিমাণ / Amount',number:true,required:true),
    FieldDef('method','পেমেন্ট (Cash/bKash/Nagad/Bank)'),
    FieldDef('ref','রেফারেন্স / Transaction ID'), FieldDef('entry_date','তারিখ / Date (YYYY-MM-DD)',required:true),
    FieldDef('notes','বিবরণ / Details',multiline:true),
  ]),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState()=>_HomePageState();
}
class _HomePageState extends State<HomePage> {
  int tab=0;
  String get today=>DateFormat('yyyy-MM-dd').format(DateTime.now());
  Future<Map<String,dynamic>> stats() async {
    final db=ClinicDb.instance;
    final income=await db.sum("SELECT SUM(amount) FROM transactions WHERE type LIKE 'Income%'");
    final expense=await db.sum("SELECT SUM(amount) FROM transactions WHERE type LIKE 'Expense%'");
    return {'patients':await db.count('patients'),'doctors':await db.count('doctors'),
      'appointments':await db.count('appointments'),'income':income,'expense':expense,'balance':income-expense};
  }
  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('মডেল ক্লিনিক এন্ড ডায়াগনস্টিক সেন্টার'), centerTitle:false),
      body: tab==0 ? dashboard() : tab==6 ? const ReportsPage() : ModulePage(module: modules[tab-1]),
      bottomNavigationBar: NavigationBar(selectedIndex:tab,
        onDestinationSelected:(v)=>setState(()=>tab=v),
        destinations: const [
          NavigationDestination(icon:Icon(Icons.dashboard),label:'হোম'),
          NavigationDestination(icon:Icon(Icons.people),label:'রোগী'),
          NavigationDestination(icon:Icon(Icons.medical_services),label:'ডাক্তার'),
          NavigationDestination(icon:Icon(Icons.calendar_month),label:'সময়'),
          NavigationDestination(icon:Icon(Icons.confirmation_number),label:'রিসেপশন'),
          NavigationDestination(icon:Icon(Icons.payments),label:'হিসাব'),
          NavigationDestination(icon:Icon(Icons.bar_chart),label:'রিপোর্ট'),
        ]),
    );
  }
  Widget dashboard()=>FutureBuilder<Map<String,dynamic>>(future:stats(),builder:(c,s){
    if(!s.hasData) return const Center(child:CircularProgressIndicator());
    final x=s.data!;
    Widget tile(String title,String value,IconData icon)=>Card(child:Padding(
      padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Icon(icon,color:Theme.of(context).colorScheme.primary,size:28),const SizedBox(height:8),
        Text(value,style:Theme.of(context).textTheme.headlineSmall),Text(title),
      ])));
    return RefreshIndicator(onRefresh:()async=>setState((){}),child:ListView(padding:const EdgeInsets.all(12),children:[
      const Text('ক্লিনিক ম্যানেজমেন্ট ড্যাশবোর্ড',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      const SizedBox(height:12),
      GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:2,childAspectRatio:1.6,
        children:[tile('মোট রোগী','${x['patients']}',Icons.people),tile('মোট ডাক্তার','${x['doctors']}',Icons.medical_services),
          tile('অ্যাপয়েন্টমেন্ট','${x['appointments']}',Icons.event),tile('মোট আয়','৳${x['income']}',Icons.trending_up),
          tile('মোট ব্যয়','৳${x['expense']}',Icons.trending_down),tile('বর্তমান ব্যালেন্স','৳${x['balance']}',Icons.account_balance)]),
      const SizedBox(height:8), const Text('দ্রুত নির্দেশনা',style:TextStyle(fontWeight:FontWeight.bold)),
      const Text('নিচের মেনু থেকে রোগী, ডাক্তার, সময়সূচি, রিসেপশন ও হিসাবের তথ্য যোগ করুন।'),
    ]));
  });
}

class ModulePage extends StatefulWidget {
  final Module module;
  const ModulePage({super.key,required this.module});
  @override State<ModulePage> createState()=>_ModulePageState();
}
class _ModulePageState extends State<ModulePage> {
  String search='';
  Future<void> refresh() async { if(mounted)setState((){}); }
  @override Widget build(BuildContext context)=>Scaffold(
    body:Column(children:[
      Padding(padding:const EdgeInsets.fromLTRB(12,12,12,4),child:TextField(
        decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'নাম বা তথ্য খুঁজুন / Search',border:OutlineInputBorder()),
        onChanged:(v)=>setState(()=>search=v))),
      Expanded(child:FutureBuilder<List<Map<String,dynamic>>>(future:ClinicDb.instance.rows(widget.module.table),
        builder:(c,s){
          if(!s.hasData)return const Center(child:CircularProgressIndicator());
          final rows=s.data!.where((r)=>r.values.any((v)=>'$v'.toLowerCase().contains(search.toLowerCase()))).toList();
          if(rows.isEmpty)return const Center(child:Text('কোনো তথ্য নেই। + চাপ দিয়ে নতুন তথ্য যোগ করুন।'));
          return ListView.builder(itemCount:rows.length,itemBuilder:(c,i){
            final row=rows[i]; final name=row['name']??row['serial']??row['category']??'রেকর্ড #${row['id']}';
            final detail=row.entries.where((e)=>e.key!='id' && e.value!=null && '${e.value}'.isNotEmpty).take(3).map((e)=>'${e.key}: ${e.value}').join(' • ');
            return Card(child:ListTile(title:Text('$name'),subtitle:Text(detail,maxLines:2,overflow:TextOverflow.ellipsis),
              onTap:()=>showForm(row),trailing:PopupMenuButton<String>(onSelected:(v)async{
                if(v=='edit')await showForm(row);
                if(v=='delete')await confirmDelete(row);
              },itemBuilder:(_)=>const [PopupMenuItem(value:'edit',child:Text('সম্পাদনা / Edit')),
                PopupMenuItem(value:'delete',child:Text('মুছুন / Delete'))])));
          });
        })),
    ]),
    floatingActionButton:FloatingActionButton.extended(onPressed:()=>showForm(null),icon:const Icon(Icons.add),label:const Text('নতুন যোগ করুন')),
  );

  Future<void> showForm(Map<String,dynamic>? old) async {
    final ctrls=<String,TextEditingController>{};
    for(final f in widget.module.fields) ctrls[f.key]=TextEditingController(text:old?[f.key]?.toString()??'');
    final key=_formKey;
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
      title:Text(old==null?'নতুন তথ্য যোগ করুন':'তথ্য সম্পাদনা করুন'),
      content:Form(key:key,child:SizedBox(width:420,child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
        for(final f in widget.module.fields) Padding(padding:const EdgeInsets.only(bottom:10),child:TextFormField(
          controller:ctrls[f.key],keyboardType:f.number?TextInputType.number:TextInputType.text,
          maxLines:f.multiline?3:1,decoration:InputDecoration(labelText:f.label,border:const OutlineInputBorder()),
          validator:(v)=>f.required&&(v==null||v.trim().isEmpty)?'এই ঘরটি পূরণ করুন':null)),
      ])))),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('বাতিল')),
        FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('সেভ করুন'))],
    ));
    if(ok==true && key.currentState!.validate()){
      final data=<String,dynamic>{};
      for(final f in widget.module.fields){
        final v=ctrls[f.key]!.text.trim();
        data[f.key]=f.number?(double.tryParse(v)??0):v;
      }
      if(widget.module.table=='patients')data['created_at']=old?['created_at']??DateTime.now().toIso8601String();
      if(old==null)await ClinicDb.instance.add(widget.module.table,data);
      else await ClinicDb.instance.edit(widget.module.table,old['id'] as int,data);
      await refresh();
    }
    for(final c in ctrls.values)c.dispose();
  }
  final _formKey=GlobalKey<FormState>();
  Future<void> confirmDelete(Map<String,dynamic> row) async {
    final yes=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('মুছে ফেলবেন?'),
      content:const Text('এই রেকর্ডটি স্থায়ীভাবে মুছে যাবে।'),actions:[
        TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('না')),
        FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('হ্যাঁ, মুছুন'))]));
    if(yes==true){await ClinicDb.instance.remove(widget.module.table,row['id'] as int);await refresh();}
  }
}

class ReportsPage extends StatelessWidget {
  const ReportsPage({super.key});
  Future<Map<String,double>> data() async {
    final db=ClinicDb.instance;
    return {'Income':await db.sum("SELECT SUM(amount) FROM transactions WHERE type LIKE 'Income%'"),
      'Expense':await db.sum("SELECT SUM(amount) FROM transactions WHERE type LIKE 'Expense%'"),
      'Doctor fees':await db.sum("SELECT SUM(fee) FROM appointments WHERE status NOT LIKE 'Cancelled%'")};
  }
  @override Widget build(BuildContext context)=>FutureBuilder<Map<String,double>>(future:data(),builder:(c,s){
    if(!s.hasData)return const Center(child:CircularProgressIndicator());
    return ListView(padding:const EdgeInsets.all(16),children:[
      const Text('হিসাব ও রিপোর্ট / Reports',style:TextStyle(fontSize:21,fontWeight:FontWeight.bold)),
      const SizedBox(height:12),
      for(final e in s.data!.entries)Card(child:ListTile(title:Text(e.key),trailing:Text('৳${e.value.toStringAsFixed(2)}',
        style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)))),
      const SizedBox(height:8),
      const Text('নোট: এই রিপোর্টে বর্তমানে সংরক্ষিত সব লেনদেনের মোট হিসাব দেখানো হয়।'),
    ]);
  });
}
