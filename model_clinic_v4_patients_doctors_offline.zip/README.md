# Model Clinic V4 — Patients and Doctors

Includes the supplied clinic logo, bilingual dashboard, local SQLite storage, doctor entry/list,
patient entry/list, and dashboard totals.

Important: records are currently stored only on this phone. Multi-phone cloud sync, staff login
and permissions, appointments/serials, commissions, accounts, payments, reports and cloud backup
are future stages. Do not rely on this demo as the clinic's only production record system.

GitHub Actions builds the Android APK from this ZIP.
