
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await DB.instance.db;
  runApp(const ClinicApp());
}

class DB {
  DB._();
  static final DB instance = DB._();
  Database? _database;
  Future<Database> get db async {
    if (_database != null) return _database!;
    final file = p.join(await getDatabasesPath(), 'model_clinic.db');
    _database = await openDatabase(file, version: 1, onCreate: (d, v) async {
      await d.execute('CREATE TABLE doctors(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, specialty TEXT, phone TEXT, fee REAL, schedule TEXT)');
      await d.execute('CREATE TABLE patients(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, age TEXT, gender TEXT, phone TEXT, address TEXT, created_at TEXT)');
    });
    return _database!;
  }
  Future<int> add(String table, Map<String,Object?> row) async => (await db).insert(table,row);
  Future<List<Map<String,Object?>>> list(String table) async => (await db).query(table, orderBy: 'id DESC');
  Future<int> count(String table) async => Sqflite.firstIntValue(await (await db).rawQuery('SELECT COUNT(*) FROM $table')) ?? 0;
}

class ClinicApp extends StatelessWidget {
  const ClinicApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false, title: 'Model Clinic',
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF343A91)), scaffoldBackgroundColor: const Color(0xFFF7FAFC)),
    home: const Home(),
  );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override State<Home> createState() => _HomeState();
}
class _HomeState extends State<Home> {
  int doctors=0, patients=0;
  @override void initState(){ super.initState(); refresh(); }
  Future<void> refresh() async {
    final d=await DB.instance.count('doctors'), p=await DB.instance.count('patients');
    if(mounted) setState(()=>{doctors=d,patients=p});
  }
  Future<void> go(Widget page) async { await Navigator.push(context,MaterialPageRoute(builder:(_)=>page)); refresh(); }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar: AppBar(title: const Text('Model Clinic')),
    body: ListView(padding: const EdgeInsets.all(16), children:[
      Card(color:Colors.white, child:Padding(padding:const EdgeInsets.all(16),child:Column(children:[
        Image.asset('assets/app_icon.png',height:140,fit:BoxFit.contain),
        const SizedBox(height:8),
        const Text('মডেল ক্লিনিক এন্ড ডায়াগনস্টিক সেন্টার',textAlign:TextAlign.center,style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
        const Text('Model Clinic & Diagnostic Center',style:TextStyle(color:Color(0xFF08A5BE),fontSize:15)),
      ]))),
      const SizedBox(height:14),
      const Text('Dashboard / ড্যাশবোর্ড',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
      Row(children:[
        Expanded(child: _Count(title:'Doctors / ডাক্তার',value:doctors,icon:Icons.medical_services)),
        Expanded(child: _Count(title:'Patients / রোগী',value:patients,icon:Icons.people)),
      ]),
      _Tile(icon:Icons.people,title:'Patients / রোগী',subtitle:'রোগী যোগ করুন ও তালিকা দেখুন',tap:()=>go(const Patients())),
      _Tile(icon:Icons.medical_services,title:'Doctors / ডাক্তার',subtitle:'ডাক্তার যোগ করুন ও তালিকা দেখুন',tap:()=>go(const Doctors())),
      const Padding(padding:EdgeInsets.all(12),child:Text('এই সংস্করণে রোগী ও ডাক্তারের তথ্য এই ফোনে অফলাইনে সংরক্ষিত হয়। একাধিক ফোনে সিঙ্ক ও কর্মীদের লগইন পরবর্তী ধাপে যুক্ত হবে।',textAlign:TextAlign.center,style:TextStyle(color:Colors.black54,fontSize:12))),
    ]),
  );
}

class _Count extends StatelessWidget {
  final String title; final int value; final IconData icon;
  const _Count({required this.title,required this.value,required this.icon});
  @override Widget build(BuildContext context)=>Expanded(child:Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(children:[Icon(icon,color:const Color(0xFF08A5BE)),Text('$value',style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)),Text(title,textAlign:TextAlign.center)]))));
}
class _Tile extends StatelessWidget {
  final IconData icon; final String title,subtitle; final VoidCallback tap;
  const _Tile({required this.icon,required this.title,required this.subtitle,required this.tap});
  @override Widget build(BuildContext context)=>Card(child:ListTile(leading:Icon(icon,color:const Color(0xFF08A5BE)),title:Text(title),subtitle:Text(subtitle),trailing:const Icon(Icons.chevron_right),onTap:tap));
}

class Doctors extends StatefulWidget { const Doctors({super.key}); @override State<Doctors> createState()=>_DoctorsState(); }
class _DoctorsState extends State<Doctors>{
  List<Map<String,Object?>> rows=[]; bool busy=true;
  @override void initState(){super.initState();load();}
  Future<void> load() async {final x=await DB.instance.list('doctors');if(mounted)setState(()=>{rows=x,busy=false});}
  Future<void> add() async {final ok=await Navigator.push<bool>(context,MaterialPageRoute(builder:(_)=>const DoctorForm()));if(ok==true)load();}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Doctors / ডাক্তার')),floatingActionButton:FloatingActionButton.extended(onPressed:add,icon:const Icon(Icons.add),label:const Text('Add doctor')),body:busy?const Center(child:CircularProgressIndicator()):rows.isEmpty?const Center(child:Text('এখনো কোনো ডাক্তার যোগ করা হয়নি')):ListView(children:rows.map((r)=>Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.medical_services)),title:Text('${r['name']}'),subtitle:Text('${r['specialty']??''}\nফোন: ${r['phone']??''} | ফি: ${r['fee']??0}'),isThreeLine:true))).toList()));
}
class DoctorForm extends StatefulWidget { const DoctorForm({super.key}); @override State<DoctorForm> createState()=>_DoctorFormState(); }
class _DoctorFormState extends State<DoctorForm>{
  final keyForm=GlobalKey<FormState>(); final name=TextEditingController(),specialty=TextEditingController(),phone=TextEditingController(),fee=TextEditingController(text:'0'),schedule=TextEditingController(); bool saving=false;
  @override void dispose(){name.dispose();specialty.dispose();phone.dispose();fee.dispose();schedule.dispose();super.dispose();}
  Future<void> save() async {if(!keyForm.currentState!.validate())return;setState(()=>saving=true);await DB.instance.add('doctors',{'name':name.text.trim(),'specialty':specialty.text.trim(),'phone':phone.text.trim(),'fee':double.tryParse(fee.text)??0,'schedule':schedule.text.trim()});if(mounted)Navigator.pop(context,true);}
  Widget field(TextEditingController c,String label,{bool required=false,TextInputType? type})=>Padding(padding:const EdgeInsets.only(bottom:12),child:TextFormField(controller:c,keyboardType:type,decoration:InputDecoration(labelText:label,border:const OutlineInputBorder()),validator:required?(v)=>(v==null||v.trim().isEmpty)?'আবশ্যক':'' :null));
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Add doctor / ডাক্তার যোগ')),body:Form(key:keyForm,child:ListView(padding:const EdgeInsets.all(16),children:[field(name,'ডাক্তারের নাম',required:true),field(specialty,'বিভাগ / Specialty'),field(phone,'মোবাইল নম্বর',type:TextInputType.phone),field(fee,'ভিজিট ফি',type:const TextInputType.numberWithOptions(decimal:true)),field(schedule,'বসার সময় / Schedule'),FilledButton(onPressed:saving?null:save,child:Text(saving?'Saving...':'সংরক্ষণ করুন'))])));
}

class Patients extends StatefulWidget { const Patients({super.key}); @override State<Patients> createState()=>_PatientsState(); }
class _PatientsState extends State<Patients>{
  List<Map<String,Object?>> rows=[]; bool busy=true;
  @override void initState(){super.initState();load();}
  Future<void> load() async {final x=await DB.instance.list('patients');if(mounted)setState(()=>{rows=x,busy=false});}
  Future<void> add() async {final ok=await Navigator.push<bool>(context,MaterialPageRoute(builder:(_)=>const PatientForm()));if(ok==true)load();}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Patients / রোগী')),floatingActionButton:FloatingActionButton.extended(onPressed:add,icon:const Icon(Icons.person_add),label:const Text('Add patient')),body:busy?const Center(child:CircularProgressIndicator()):rows.isEmpty?const Center(child:Text('এখনো কোনো রোগী যোগ করা হয়নি')):ListView(children:rows.map((r)=>Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:Text('${r['name']}'),subtitle:Text('বয়স: ${r['age']??''} | ${r['gender']??''}\nফোন: ${r['phone']??''}\n${r['address']??''}'),isThreeLine:true))).toList()));
}
class PatientForm extends StatefulWidget { const PatientForm({super.key}); @override State<PatientForm> createState()=>_PatientFormState(); }
class _PatientFormState extends State<PatientForm>{
  final keyForm=GlobalKey<FormState>(); final name=TextEditingController(),age=TextEditingController(),phone=TextEditingController(),address=TextEditingController(); String gender='উল্লেখ নেই'; bool saving=false;
  @override void dispose(){name.dispose();age.dispose();phone.dispose();address.dispose();super.dispose();}
  Widget field(TextEditingController c,String label,{bool required=false,TextInputType? type,int lines=1})=>Padding(padding:const EdgeInsets.only(bottom:12),child:TextFormField(controller:c,keyboardType:type,maxLines:lines,decoration:InputDecoration(labelText:label,border:const OutlineInputBorder()),validator:required?(v)=>(v==null||v.trim().isEmpty)?'আবশ্যক':'' :null));
  Future<void> save() async {if(!keyForm.currentState!.validate())return;setState(()=>saving=true);await DB.instance.add('patients',{'name':name.text.trim(),'age':age.text.trim(),'gender':gender,'phone':phone.text.trim(),'address':address.text.trim(),'created_at':DateTime.now().toIso8601String()});if(mounted)Navigator.pop(context,true);}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Add patient / রোগী যোগ')),body:Form(key:keyForm,child:ListView(padding:const EdgeInsets.all(16),children:[field(name,'রোগীর নাম',required:true),field(age,'বয়স',type:TextInputType.number),DropdownButtonFormField<String>(value:gender,decoration:const InputDecoration(labelText:'লিঙ্গ',border:OutlineInputBorder()),items:['উল্লেখ নেই','পুরুষ','নারী','অন্যান্য'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setState(()=>gender=v??'উল্লেখ নেই')),const SizedBox(height:12),field(phone,'মোবাইল নম্বর',type:TextInputType.phone),field(address,'ঠিকানা',lines:2),FilledButton(onPressed:saving?null:save,child:Text(saving?'Saving...':'সংরক্ষণ করুন'))])));
}
